require('../sass/style.scss')
require('./script.js');