<?php get_header(); ?>

<div class="content">


</div>

<?php get_footer(); ?>