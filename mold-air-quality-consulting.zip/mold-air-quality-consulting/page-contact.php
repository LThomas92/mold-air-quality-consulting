<?php get_header(); ?>

<div class="content">

    <div class="c-contact">
        <?php echo the_content(); ?>
    </div>

</div>

<?php get_footer(); ?>